//-------------------------------------------------------------------------
// Desc:	Set packing for FLAIM structures.
// Tabs:	3
//
// Copyright (c) 2002-2007 Novell, Inc. All Rights Reserved.
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; version 2.1
// of the License.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Library Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, contact Novell, Inc.
//
// To contact Novell about this file by physical or electronic mail, 
// you may find current contact information at www.novell.com.
//
// $Id$
//------------------------------------------------------------------------------

// IMPORTANT NOTE: DO NOT put #ifdef FPACKON_H in this file!  We want
// to be able to include it in many different places.

#if !defined( FLM_UNIX) && !defined( FLM_64BIT)
	#ifdef FLM_WIN
		// For some reason, Windows emits a warning when the packing
		// is changed.

		#pragma warning( disable : 4103)
	#endif
	
	#pragma pack(push, 1)
#endif
