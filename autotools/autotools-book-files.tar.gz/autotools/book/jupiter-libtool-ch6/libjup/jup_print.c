#include "libjupiter.h"
#include "jupcommon.h"

int jupiter_print(const char * name)
{
    print_routine(name);
}
