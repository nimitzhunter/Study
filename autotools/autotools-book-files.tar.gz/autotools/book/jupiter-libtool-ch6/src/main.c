#include "libjupiter.h"

int main(int argc, char * argv[])
{
    jupiter_print(argv[0]);
    return 0;
}
